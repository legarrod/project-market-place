Para correr este proyecto verifique lo siguiente:

- Que tenta instalada la version 16 de nodejs
  * si no la tiene instalada o tiene una version diferente puede investigar un poco sobre "nvm"

luego hacer lo siguiente:

git clone https://github.com/legarrod/project-market-place.git

- dentro de la carpeta del proyecto abre la terminal y corre lo siguiente:

npm install
npm start

